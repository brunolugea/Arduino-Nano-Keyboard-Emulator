import serial
import serial.tools.list_ports
from pynput.keyboard import Controller

# VID y PID del CH340 (Nano clon típico)
NANO_VID = "1A86"
NANO_PID = "7523"

def encontrar_puerto():
    puertos = serial.tools.list_ports.comports()
    for p in puertos:
        if (p.vid is not None and p.pid is not None and
            format(p.vid, '04X') == NANO_VID and
            format(p.pid, '04X') == NANO_PID):
            return p.device
    return None

puerto = encontrar_puerto()
if not puerto:
    print("⚠️ No encontré el Arduino Nano (CH340)")
    exit()

print(f"✅ Conectado en {puerto}")
arduino = serial.Serial(puerto, 9600)
keyboard = Controller()

mapa = {
    "BTN1": "1",
    "BTN2": "2",
    "BTN3": "3",
    "BTN4": "4",
    "BTN5": "5",
    "BTN6": "6",
    "BTN7": "7",
    "BTN8": "8",
    "BTN9": "9",
    "BTN10": "0",
    "BTN11": "."
}

while True:
    try:
        linea = arduino.readline().decode(errors="ignore").strip()
        for base, tecla in mapa.items():
            if linea == base + "_DOWN":
                keyboard.press(tecla)
                print(f"↓ {tecla}")
            elif linea == base + "_UP":
                keyboard.release(tecla)
                print(f"↑ {tecla}")
    except Exception as e:
        print("❌ Error:", e)
        break
